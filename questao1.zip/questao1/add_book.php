<?php

require 'database.php';

if (!empty($_POST['titulo']) && !empty($_POST['autor']) && !empty($_POST['ano'])) {

    $stmt = $db->prepare("INSERT INTO livros (titulo, autor, ano) VALUES (?, ?, ?)");
    $stmt->execute([$_POST['titulo'], $_POST['autor'], $_POST['ano']]);
}

header("Location: index.php");
exit;
?>
