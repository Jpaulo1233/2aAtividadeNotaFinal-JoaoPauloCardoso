<?php include 'database.php'; ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciador de Tarefas</title>
    <style>
        body{
            font-family: Arial;
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            padding: 20px;
        }
        .bloco{
            background-color: #fff;
            padding: 20px;
            width: 500px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        button{
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
        }
        input{
            width: 75%;
            padding: 8px;
            margin: 5px 0;
        }
        table{
            width: 100%;
            margin-top: 10px;
            border-collapse: collapse;
        }
        td, th{
            border-bottom: 1px solid #ccc;
            padding: 8px;
        }
        .concluida{
            text-decoration: line-through;
            color: gray;
        }
        h2{
            margin-top: 30px;
        }
        .btn-small{
            width: auto;
            padding: 5px 10px;
            margin-right: 5px;
        }
    </style>
</head>
<body>

<div class="bloco">

    <h2>Adicionar Tarefa</h2>
    <form action="add_tarefa.php" method="POST">
        Descrição<br/>
        <input type="text" name="descricao" required><br/><br/>
        Data de Vencimento<br/>
        <input type="date" name="vencimento" required><br/><br/>
        <button type="submit">Adicionar</button>
    </form>

    <h2>Tarefas Não Concluídas</h2>
    <table>
        <tr>
            <th>Descrição</th>
            <th>Vencimento</th>
            <th>Ações</th>
        </tr>
        <?php
        $tarefas = $db->query("SELECT * FROM tarefas WHERE concluida = 0 ORDER BY vencimento ASC");
        foreach($tarefas as $t){
            echo "<tr>
                    <td>{$t['descricao']}</td>
                    <td>{$t['vencimento']}</td>
                    <td>
                        <form action='update_tarefa.php' method='POST' style='display:inline'>
                            <input type='hidden' name='id' value='{$t['id']}'>
                            <button class='btn-small' type='submit'>Concluir</button>
                        </form>
                        <form action='delete_tarefa.php' method='POST' style='display:inline'>
                            <input type='hidden' name='id' value='{$t['id']}'>
                            <button class='btn-small' type='submit'>Excluir</button>
                        </form>
                    </td>
                  </tr>";
        }
        ?>
    </table>

    <h2>Tarefas Concluídas</h2>
    <table>
        <tr>
            <th>Descrição</th>
            <th>Vencimento</th>
            <th>Ações</th>
        </tr>
        <?php
        $tarefas_concluidas = $db->query("SELECT * FROM tarefas WHERE concluida = 1 ORDER BY vencimento ASC");
        foreach($tarefas_concluidas as $t){
            echo "<tr>
                    <td class='concluida'>{$t['descricao']}</td>
                    <td class='concluida'>{$t['vencimento']}</td>
                    <td>
                        <form action='delete_tarefa.php' method='POST' style='display:inline'>
                            <input type='hidden' name='id' value='{$t['id']}'>
                            <button class='btn-small' type='submit'>Excluir</button>
                        </form>
                    </td>
                  </tr>";
        }
        ?>
    </table>

</div>

</body>
</html>
