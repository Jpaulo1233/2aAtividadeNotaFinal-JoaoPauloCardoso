<?php include 'database.php'; ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Banco de Dados Livraria</title>

    <style>
        body{
            font-family: Arial;
            background-color: #f0f0f0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: flex-start;
        }
        .bloco{
            background-color: #fff;
            padding: 20px;
            width: 500px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        input{
            width: 75%;
            padding: 8px;
            margin: 5px 0;
        }
        button{
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
        }
        table{
            width: 100%;
            margin-top: 10px;
            border-collapse: collapse;
        }
        td, th{
            border-bottom: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }
        h2{
            margin-top: 30px;
            color: #005187;
            
        }
    </style>
</head>
<body>

<div class="bloco">

    <h2>Adicionar Livro</h2>

    <form action="add_book.php" method="POST">
        Título<br/>
        <input type="text" name="titulo" required><br/><br/>

        Autor<br/>
        <input type="text" name="autor" required><br/><br/>

        Ano<br/>
        <input type="number" name="ano" required><br/><br/>

        <button type="submit">Adicionar</button>
    </form>

    <h2>Livros Cadastrados</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Título</th>
            <th>Autor</th>
            <th>Ano</th>
        </tr>

        <?php
        $livros = $db->query("SELECT * FROM livros");

        foreach($livros as $l){
            echo "
            <tr>
                <td>{$l['id']}</td>
                <td>{$l['titulo']}</td>
                <td>{$l['autor']}</td>
                <td>{$l['ano']}</td>
            </tr>
            ";
        }
        ?>
    </table>

    <h2>Excluir Livro</h2>

    <form action="delete_book.php" method="POST">
        ID do livro<br/>
        <input type="number" name="id" required><br/><br/>

        <button type="submit">Excluir</button>
    </form>

</div>

</body>
</html>
